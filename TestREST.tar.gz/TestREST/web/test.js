/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function validateform() {
    var id = document.myform.id.value;
    var name = document.myform.name.value;
    var email = document.myform.email.value;

    if (name == null || name == "" || email == "" || email == null) {
        alert("Provide All valid data");
        return false;

    }
    if (isNaN(id) || id == "" || id == null) {
        document.getElementById("numloc").innerHTML = "* Numbers Only";
        return false;
    }
    var atposition = email.indexOf("@");
    var dotposition = email.lastIndexOf(".");
    if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= email.length) {
        alert("Please enter a valid e-mail address");
        return false;
    }


}
function showForm() {
    document.getElementById("theform").style.display = "block";

}
function validate()
{
    var id = document.myform.id.value;
    if (isNaN(id) || id == "" || id == null) {
        document.getElementById("numloc").innerHTML = "* Numbers Only";
        return false;
    }
}