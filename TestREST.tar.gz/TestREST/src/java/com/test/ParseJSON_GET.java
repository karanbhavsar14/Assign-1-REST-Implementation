/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mtech
 */
public class ParseJSON_GET extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            out.println("<style>");
            out.println("table, th, td ");
            out.println("{ border: 1px solid black; border-collapse: collapse;margin-left:15%}");
            out.println("th, td { padding: 15px; }");
            out.println(".demo{width:900px;margin:0 auto;margin-top: 5%;border:1px solid black}");
            out.println("</style>");
            out.println("<link href=\"style.css\" rel=\"stylesheet\" type=\"text/css\">");
            String uname = request.getParameter("name");
            String pass = request.getParameter("email");

            String authstring = uname + ":" + pass;

            String output = "";

            try {
                URL url = null;
                String str = request.getParameter("Events");

                if (str.equals("getSpecific")) {

                    int id = Integer.parseInt(request.getParameter("id"));
                    url = new URL("http://localhost:8080/TestREST/webresources/v2/testcontroller/getParticularUser/" + id + "/" + authstring);

                } else if (str.equals("getAll")) {
                    url = new URL("http://localhost:8080/TestREST/webresources/v2/testcontroller/getAllUsers/" + authstring);

                } else {
                    int id = Integer.parseInt(request.getParameter("id"));
                    url = new URL("http://localhost:8080/TestREST/webresources/v2/testcontroller/DeleteUser/" + id + "/" + authstring);
                }

                //Parse URL into HttpURLConnection in order to open the connection in order to get the JSON data
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                //Set the request to GET or POST as per the requirements
                conn.setRequestMethod("GET");

                conn.setRequestProperty("Accept", "application/json");

                //Use the connect method to create the connection bridge
                //Get the response status of the Rest API
                int responsecode = conn.getResponseCode();

                //Iterating condition to if response code is not 200 then throw a runtime exception
                //else continue the actual process of getting the JSON data
                if (responsecode != 200) {
                    throw new RuntimeException("HttpResponseCode: " + responsecode);
                } else {
                    //Scanner functionality will read the JSON data from the stream
                    BufferedReader br = new BufferedReader(new InputStreamReader(
                            (conn.getInputStream())));

                    output = br.readLine();
                    out.println("<div class=\"demo\">");
                    out.print("<br>" + output);
                }

                //JSONParser reads the data from string object and break each data into key value pairs
                JSONParser parse = new JSONParser();
                //Type caste the parsed json data in json object
                JSONObject jobj = (JSONObject) parse.parse(output);
                //Store the JSON object in JSON array as objects (For level 1 array element i.e Results)
                JSONArray jsonarr_1 = (JSONArray) jobj.get("userData");
                //Get data for Results add

                out.println("<br><br>");

                out.println("<table style=\"width:50%\">");
                out.println("<br><b><h3 style=\"margin-left:32%\"><u>Parsed JSON Data in Table Form</u></h2></b><br>");
                out.println("<tr>");
                out.println("<th>User-ID</th>");
                out.println("<th>User-Name</th>");
                out.println("<th>Email-ID</th>");
                out.println("<th>Contact-No</th>");
                out.println("</tr>");

                for (int i = 0; i < jsonarr_1.size(); i++) {
                    //Store the JSON objects in an array
                    //Get the index of the JSON object and print the values as per the index
                    JSONObject jsonobj_1 = (JSONObject) jsonarr_1.get(i);
                    //Store the JSON object in JSON array as objects (For level 2 array element i.e Address Components)
                    out.println("<tr><td>" + jsonobj_1.get("id") + "</td>");
                    out.println("<td>" + jsonobj_1.get("name") + "</td>");
                    out.println("<td>" + jsonobj_1.get("email") + "</td>");
                    out.println("<td>" + jsonobj_1.get("number") + "</td></tr>");

                }
                out.println("</table>");
                out.println("<br></div>");
                //Disconnect the HttpURLConnection stream
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
