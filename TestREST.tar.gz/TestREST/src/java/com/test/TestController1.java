/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import static com.test.TestController.validate;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author mtech
 */
@Path("v1/testcontroller")
public class TestController1 {

    JsonObject res = new JsonObject();
    JsonArray obj = new JsonArray();
    ResultSet rs;

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of TestController1
     */
    public TestController1() {
    }

    /**
     * Retrieves representation of an instance of com.test.TestController1
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Path("getAllUsers/{authstring}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getDataInJSON(@PathParam("authstring") String authstring) throws ClassNotFoundException, SQLException, URISyntaxException {

        JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
        JsonObject json1 = new JsonObject();
        json1.addProperty("key", "use updated version");
        data_json.add(json1);
        res.add("userData", data_json);
        return res.toString();
    }

    /**
     * PUT method for updating or creating an instance of TestController1
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
