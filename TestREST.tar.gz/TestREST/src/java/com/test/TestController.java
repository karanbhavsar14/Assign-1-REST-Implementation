/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.awt.Button;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import javax.servlet.http.Cookie;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import sun.misc.BASE64Decoder;

/**
 * REST Web Service
 *
 * @author mtech
 */
@Path("v2/testcontroller")
public class TestController {

    JsonObject res = new JsonObject();
    JsonArray obj = new JsonArray();
    ResultSet rs;

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of TestController
     */
    public TestController() throws URISyntaxException {

    }

    /**
     * Retrieves representation of an instance of com.test.TestController
     *
     * @return an instance of java.lang.String
     */
    public static int validate(String authstring) throws SQLException, ClassNotFoundException {
        int i = 0;
        String s1 = null;
        ResultSet rs;
        Connection cn = connectDB.getConnect();
        java.sql.Statement st1 = cn.createStatement();

        String q = "select name,email from user";

        rs = st1.executeQuery(q);

        while (rs.next()) {

            String auth = rs.getString("name") + ":" + rs.getString("email");

            if (auth.equals(authstring)) {
                i = 1;

                s1 = "User Authenticate !!!";
                break;

            } else {

                s1 = "Invalid User !!!";

            }

        }

        return i;
    }

    @GET
    @Path("getAllUsers/{authstring}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getDataInJSON(@PathParam("authstring") String authstring) throws ClassNotFoundException, SQLException, URISyntaxException {
        int i = validate(authstring);
        if (i != 1) {
            return "Invalid User !!!";
        }

        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();

        rs = st.executeQuery("select * from user");

        while (rs.next()) {
            JsonObject object = new JsonObject();
            object.addProperty("id", rs.getInt("id"));
            object.addProperty("name", rs.getString("name"));
            object.addProperty("email", rs.getString("email"));
            object.addProperty("number", rs.getInt("number"));

            obj.add(object);
        }

        res.add("userData", obj);

        return res.toString();
    }

    @GET
    @Path("getParticularUser/{id}/{authstring}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getByPath(@PathParam("id") int id, @PathParam("authstring") String authstring) throws ClassNotFoundException, SQLException {

        int i = validate(authstring);
        if (i != 1) {
            return "Invalid User !!!";
        }

        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();

        rs = st.executeQuery("select * from user where id = " + id);

        if (rs.next()) {

            JsonObject object = new JsonObject();

            object.addProperty("id", rs.getInt("id"));
            object.addProperty("name", rs.getString("name"));
            object.addProperty("email", rs.getString("email"));
            object.addProperty("number", rs.getInt("number"));
            obj.add(object);
            res.add("userData", obj);

            return res.toString();
        } else {
            return "Data not Available !!!";
        }
    }

    @PUT
    @Path("reg/{name}/{email}/{number}")
    @Consumes(MediaType.APPLICATION_JSON)
    public String putJson(@PathParam("name") String name, @PathParam("email") String email, @PathParam("number") int number) throws ClassNotFoundException, SQLException, Exception {

        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();
        String q = "INSERT into user(name,email,number) VALUES ('" + name + "','" + email + "','" + number + "')";
        st.executeUpdate(q);

        return "inserted";

    }

    @GET
    @Path("DeleteUser/{id}/{authstring}")
    @Produces(MediaType.APPLICATION_JSON)
    public String deleteJson(@PathParam("id") int id, @PathParam("authstring") String authstring) throws ClassNotFoundException, SQLException {
        int i = validate(authstring);
        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();

        if (i != 1) {
            return "Invalid User !!!";
        }
        rs = st.executeQuery("select * from user where id = " + id);

        if (rs.next()) {
            st.executeUpdate("DELETE FROM user WHERE id = " + id);
            String s1 = "Data Deleted of Selected ID : " + id;
            return s1;

        } else {
            return "Data Not Available !!!";
        }

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(@FormParam("id") int id, @FormParam("name") String name, @FormParam("email") String email, @FormParam("number") int number) throws ClassNotFoundException, SQLException, URISyntaxException, Exception {

        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();
        String q = "UPDATE user SET name = '" + name + "',email = '" + email + "',number = '" + number + "' WHERE id='" + id + "'";

        st.executeUpdate(q);

        java.net.URI location = new java.net.URI("http://localhost:8080/TestREST/Login.jsp");
        return Response.temporaryRedirect(location).build();
    }

}
