
package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author mtech
 */
public class connectDB {
    public static Connection getConnect() throws ClassNotFoundException, SQLException
    {
        com.mysql.jdbc.Connection cn = null;
        Class.forName("com.mysql.jdbc.Driver");
        cn = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/restdb", "root", "root");
        return cn;
    }
}