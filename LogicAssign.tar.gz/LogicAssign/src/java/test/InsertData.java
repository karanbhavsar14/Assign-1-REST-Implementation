/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;

/**
 *
 * @author mtech
 */
public class InsertData {

    public void deleteTable() throws SQLException, ClassNotFoundException {
        Connection cn = connectDB.getConnect();
        java.sql.Statement st = cn.createStatement();
        String q = "truncate busDetails";
        st.executeUpdate(q);
        
    }

    public void insert() throws Exception {
        try {

           Connection cn = connectDB.getConnect();
            PreparedStatement sql_statement = null;
            String jdbc_insert_sql = "INSERT INTO busDetails"
                    + "(bus) VALUES"
                    + "(?)";
            sql_statement = (PreparedStatement) cn.prepareStatement(jdbc_insert_sql);
            FileInputStream input = new FileInputStream("/home/mtech/LogicAssign/web/cities.xls");
            POIFSFileSystem fs = new POIFSFileSystem(input);
            HSSFWorkbook wb = new HSSFWorkbook(fs);
            HSSFSheet sheet = wb.getSheetAt(0);
            Iterator rows = sheet.rowIterator();
            for (int i = 0; i < sheet.getLastRowNum(); i++) {
                HSSFRow row = sheet.getRow(i);
                String from = row.getCell(0).getStringCellValue();
                String sql = "INSERT INTO busDetails VALUES('" + from + "')";
                PreparedStatement pstm = (PreparedStatement) cn.prepareStatement(sql);
                pstm.executeUpdate();
                System.out.println("Import rows " + i);
            }
            while (rows.hasNext()) {
                HSSFRow row = (HSSFRow) rows.next();
                Iterator cells = row.cellIterator();
                while (cells.hasNext()) {
                    HSSFCell cell = (HSSFCell) cells.next();
                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_STRING: //handle string columns
                            sql_statement.setString(1,
                                    cell.getStringCellValue());
                            break;
                        case Cell.CELL_TYPE_NUMERIC: //handle double data
                            sql_statement.setDouble(2, cell.getNumericCellValue());
                            break;

                    }
                }
            }
            sql_statement.executeUpdate(); //we can execute the statement before  
            cn.commit();
            cn.close();
            input.close();
            System.out.println("Success import excel to mysql table");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        } catch (SQLException ex) {
            System.out.println(ex);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }
}
