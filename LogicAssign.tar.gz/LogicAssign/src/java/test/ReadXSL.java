/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;

/**
 *
 * @author mtech
 */
public class ReadXSL extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            out.println("<style>");
            out.println("table, th, td ");
            out.println("{ border: 1px solid black; border-collapse: collapse;margin-left:15%}");
            out.println("th, td { padding: 15px; }");
            out.println(".demo{width:900px;margin:0 auto;margin-top: 5%;border:1px solid black}");
            out.println("</style>");

            List sheetData = new ArrayList();
            String from[] = new String[50];
            String to[] = new String[50];
            String cc[] = new String[50];
            Double time[] = new Double[50];
            Double price[] = new Double[50];
            FileInputStream fis = null;

            String Source = (String) request.getParameter("sourceCity"); 
            String Destination = request.getParameter("destCity");
            
            try {
                HSSFWorkbook workbook = new HSSFWorkbook(fis);
                HSSFSheet sheet = workbook.getSheetAt(0);
                Iterator rows = sheet.rowIterator();

                out.println("<br><br>");
                out.println("<table style=\"width:50%\">");
                out.println("<br><b><h2 style=\"margin-left:32%\"><u>Bus Details</u></h2></b><br>");
                out.println("<tr>");
                out.println("<th>Source</th>");
                out.println("<th>Destination</th>");
                out.println("<th>Traveller</th>");
                out.println("<th>Time</th>");
                out.println("<th>Rupees</th>");
                //out.println(" <th>Total Rupees</th>");
                out.println("</tr>");

                while (rows.hasNext()) {
                    HSSFRow row = (HSSFRow) rows.next();
                    Iterator cells = row.cellIterator();

                    List data = new ArrayList();
                    while (cells.hasNext()) {
                        HSSFCell cell = (HSSFCell) cells.next();
                        data.add(cell);
                    }

                    sheetData.add(data);
                }

                for (int i = 0; i < sheetData.size(); i++) {
                    List list = (List) sheetData.get(i);
                    HSSFCell cell = (HSSFCell) list.get(0);
                    HSSFCell cell1 = (HSSFCell) list.get(1);
                    HSSFCell cell2 = (HSSFCell) list.get(2);
                    HSSFCell cell3 = (HSSFCell) list.get(3);
                    HSSFCell cell4 = (HSSFCell) list.get(4);

                    time[i] = cell3.getNumericCellValue();
                    price[i] = cell4.getNumericCellValue();
                    from[i] = cell.getStringCellValue();
                    to[i] = cell1.getStringCellValue();
                    cc[i] = cell2.getStringCellValue();

                }
            } catch (Exception e) {
                out.println("hello filenot found");
                e.printStackTrace();
            }
            for (int i = 0; i < from.length; i++) {
                if (from[i].equalsIgnoreCase(Source)) {
                    if (Source.equalsIgnoreCase(Destination)) {
                        out.println("<tr><td colspan=\"5\"><label style=\"margin-left:30%\">Not allowed,Please select Valid Routes !!</label></td></tr>");
                        break;
                    } else if (to[i].equalsIgnoreCase(Destination)) {
                        out.println("<tr><td>" + from[i] + "</td><td>" + to[i] + "</td><td>" + cc[i] + "</td><td>" + time[i] + "</td><td>" + price[i] + "</td></tr>");
                        

                    } else {

                        Double a = price[i];
                        Double x = time[i];
                        for (int j = 0; j < from.length; j++) {
                            if (to[i].equals(from[j])) {
                                if (to[j].equalsIgnoreCase(Destination)) {
                                    Double b = price[j];
                                    Double c = a + b;
                                    
                                    Double y = time[j];
                                    Double z = x + y;
                                    out.println("<tr><td>" + from[i] + "</td><td>" + to[i] + "</td><td>" + cc[i] + "</td><td>" + time[i] + "</td><td>" + price[i] + "</td></tr>");
                                    out.println("<tr><td>" + from[j] + "</td><td>" + to[j] + "</td><td>" + cc[j] + "</td><td>" + time[j] + "</td><td>" + price[j] + "</td><td>" + c + "</td><td>"+z+" hour</td></tr>");
                                }
                            }
                        }
                    }
                }
               

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
